#pragma once

#define WIN32_LEAN_AND_MEAN

#define _WIN32_WINNT _WIN32_WINNT_WINXP

#if(DATASERVER_UPDATE>=801)
#define DATASERVER_VERSION "1.0.0.1"
#elif(DATASERVER_UPDATE>=601)
#define DATASERVER_VERSION "1.0.0.1"
#elif(DATASERVER_UPDATE>=401)
#define DATASERVER_VERSION "1.0.0.1"
#elif(DATASERVER_UPDATE>=201)
#define DATASERVER_VERSION "1.0.0.1"
#elif(DATASERVER_UPDATE>=101)
#define DATASERVER_VERSION "1.0.1.3"
#elif(DATASERVER_UPDATE>=99)
#define DATASERVER_VERSION "1.0.0.1"
#else
#define DATASERVER_VERSION "1.0.0.1"
#endif

#ifndef DATASERVER_UPDATE
#define DATASERVER_UPDATE 803
#endif

// System Include
#include <windows.h>
#include <winsock2.h>
#include <commctrl.h>
#include <sql.h>
#include <sqltypes.h>
#include <sqlext.h>
#include <process.h>
#include <iostream>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <time.h>
#include <math.h>
#include <map>
#include <vector>
#include <queue>
#include <string>
#include <Rpc.h>
#include <dbghelp.h>
#include <Psapi.h>
#include <wincrypt.h>

#pragma comment(lib,"User32.lib")
#pragma comment(lib,"ws2_32.lib")
#pragma comment(lib,"Rpcrt4.lib")
#pragma comment(lib,"dbghelp.lib")
#pragma comment(lib,"Psapi.lib")
#pragma comment(lib,"Gdi32.lib")
#pragma comment(lib,"odbc32.lib")
#pragma comment(lib,"Winmm.lib")
#pragma comment (lib, "Crypt32.lib")

extern char CustomerName[100];
extern char ResetTable[50];
extern int MaxCharacters;
extern int DisableCheckName;
extern int RecycleSerial;

typedef unsigned __int64 QWORD;


#define ENC(x) (char*)x

#define CUSTOM_DATASERVER