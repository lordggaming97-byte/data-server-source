#include "stdafx.h"
#include "ElementSlot.h"
#include "QueryManager.h"
#include "SocketManager.h"

CElementSlot gElementSlot;

CElementSlot::CElementSlot()
{
}

CElementSlot::~CElementSlot()
{
}

void CElementSlot::ElementSlotGetSave(SDHP_ELEMENT_SLOT_GET_SAVE_RECV * lpMsg, int index)
{
	SDHP_ELEMENT_SLOT_SAVE_SEND pMsg;

	pMsg.header.set(0x05, 0x51, sizeof(pMsg));

	pMsg.index = lpMsg->index;

	memcpy(pMsg.account, lpMsg->account, sizeof(pMsg.account));

	memcpy(pMsg.name, lpMsg->name, sizeof(pMsg.name));

	if (gQueryManager.ExecQuery("SELECT ElementSlot FROM Character WHERE AccountID='%s' and Name='%s'", lpMsg->account, lpMsg->name) == 0 || gQueryManager.Fetch() == SQL_NO_DATA)
	{
		gQueryManager.Close();

		std::memset(pMsg.ElementSlot, 0xFF, sizeof(pMsg.ElementSlot));
	}
	else {
		gQueryManager.GetAsBinary("ElementSlot", pMsg.ElementSlot[0], sizeof(pMsg.ElementSlot));

		gQueryManager.Close();
	}

	gSocketManager.DataSend(index, (BYTE*)&pMsg, sizeof(pMsg));
}

void CElementSlot::ElementSlotSaveRecv(SDHP_ELEMENT_SLOT_SAVE_RECV * lpMsg)
{
	if (gQueryManager.ExecQuery("SELECT AccountID FROM Character WHERE AccountID='%s' and name='%s'", lpMsg->account, lpMsg->name) == 0 || gQueryManager.Fetch() == SQL_NO_DATA)
	{
		gQueryManager.Close();
	}
	else {
		gQueryManager.Close();

		gQueryManager.BindParameterAsBinary(1, lpMsg->ElementSlot[0], sizeof(lpMsg->ElementSlot));
		gQueryManager.ExecQuery("UPDATE Character SET ElementSlot=? WHERE AccountID='%s' and name='%s'", lpMsg->account, lpMsg->name);
		gQueryManager.Close();
	}
}
