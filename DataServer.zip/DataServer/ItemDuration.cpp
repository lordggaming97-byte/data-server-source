#include "stdafx.h"
#include "ItemDuration.h"
#include "SocketManager.h"
#include "QueryManager.h"
#include "Util.h"

ItemDuration gItemDuration;

ItemDuration::ItemDuration()
{

}

ItemDuration::~ItemDuration()
{

}

void ItemDuration::CheckDurationItens()
{
	this->ItemDurationList.clear();

	if (gQueryManager.ExecQuery("SELECT Time, ItemSerial FROM PeriodicItem") != 0)
	{
		while (gQueryManager.Fetch() != SQL_NO_DATA)
		{
			DWORD timeitem = gQueryManager.GetAsInteger("Time") + (1440 * 60);

			if (timeitem <= ((DWORD)time(0)))
			{
				ITEM_DURATION_INFO ItemDuration;

				ItemDuration.Clear();

				ItemDuration.Time = timeitem;

				ItemDuration.Serial = gQueryManager.GetAsInteger("ItemSerial");

				this->ItemDurationList.push_back(ItemDuration);
			}
		}
	}

	gQueryManager.Close();

	int Count = 0;

	for (std::vector<ITEM_DURATION_INFO>::iterator it = this->ItemDurationList.begin(); it != this->ItemDurationList.end(); it++)
	{
		if (it->Serial != 0)
		{
			gQueryManager.ExecQuery("EXEC [WZ_DeleteItemPeriodic] '%d'", it->Serial);
			gQueryManager.Fetch();
			gQueryManager.Close();

			Count++;
		}

		if (Count >= 25000)
		{
			break;
		}
	}

	LogAdd(LOG_BLACK, "%d/%d itens to delete", Count, this->ItemDurationList.size());
}

void ItemDuration::GDPeriodicItemRecv(SDHP_PERIODIC_ITEM_RECV * lpMsg, int index)
{
	BYTE send[4096];

	SDHP_PERIODIC_ITEM_SEND pMsg;

	pMsg.header.set(0x18, 0x05, 0);

	int size = sizeof(pMsg);

	pMsg.index = lpMsg->index;

	memcpy(pMsg.account, lpMsg->account, sizeof(pMsg.account));

	pMsg.count = 0;

	SDHP_PERIODIC_ITEM2 info;

	for (int n = 0; n < lpMsg->count; n++)
	{
		SDHP_PERIODIC_ITEM1* lpInfo = (SDHP_PERIODIC_ITEM1*)(((BYTE*)lpMsg) + sizeof(SDHP_PERIODIC_ITEM_RECV) + (sizeof(SDHP_PERIODIC_ITEM1)*n));

		if (gQueryManager.ExecQuery("SELECT Time FROM PeriodicItem WHERE ItemSerial=%d", lpInfo->serial) == 0 || gQueryManager.Fetch() == SQL_NO_DATA)
		{
			gQueryManager.Close();

			info.slot = lpInfo->slot;
			info.serial = lpInfo->serial;
			info.time = 0;
		}
		else
		{
			info.slot = lpInfo->slot;
			info.serial = lpInfo->serial;
			info.time = (DWORD)gQueryManager.GetAsInteger64("Time");

			gQueryManager.Close();
		}

		memcpy(&send[size], &info, sizeof(info));
		size += sizeof(info);

		pMsg.count++;
	}

	pMsg.header.size[0] = SET_NUMBERHB(size);
	pMsg.header.size[1] = SET_NUMBERLB(size);

	memcpy(send, &pMsg, sizeof(pMsg));

	gSocketManager.DataSend(index, send, size);
}

void ItemDuration::GDPeriodicWarehouseItemRecv(SDHP_PERIODIC_ITEM_RECV * lpMsg, int index)
{
	BYTE send[4096];

	SDHP_PERIODIC_ITEM_SEND pMsg;

	pMsg.header.set(0x18, 0x06, 0);

	int size = sizeof(pMsg);

	pMsg.index = lpMsg->index;

	memcpy(pMsg.account, lpMsg->account, sizeof(pMsg.account));

	pMsg.count = 0;

	SDHP_PERIODIC_ITEM2 info;

	for (int n = 0; n < lpMsg->count; n++)
	{
		SDHP_PERIODIC_ITEM1* lpInfo = (SDHP_PERIODIC_ITEM1*)(((BYTE*)lpMsg) + sizeof(SDHP_PERIODIC_ITEM_RECV) + (sizeof(SDHP_PERIODIC_ITEM1)*n));

		if (gQueryManager.ExecQuery("SELECT Time FROM PeriodicItem WHERE ItemSerial=%d", lpInfo->serial) == 0 || gQueryManager.Fetch() == SQL_NO_DATA)
		{
			gQueryManager.Close();

			info.slot = lpInfo->slot;
			info.serial = lpInfo->serial;
			info.time = 0;
		}
		else
		{
			info.slot = lpInfo->slot;
			info.serial = lpInfo->serial;
			info.time = (DWORD)gQueryManager.GetAsInteger64("Time");

			gQueryManager.Close();
		}

		memcpy(&send[size], &info, sizeof(info));
		size += sizeof(info);

		pMsg.count++;
	}

	pMsg.header.size[0] = SET_NUMBERHB(size);
	pMsg.header.size[1] = SET_NUMBERLB(size);

	memcpy(send, &pMsg, sizeof(pMsg));

	gSocketManager.DataSend(index, send, size);
}

void ItemDuration::GDPickUpItemRecv(SDHP_PERIODIC_PICK_UP_RECV * lpMsg, int index)
{
	SDHP_PERIODIC_PICK_UP_SEND pMsg;

	pMsg.header.set(0x18, 0x04, sizeof(pMsg));

	pMsg.index = lpMsg->index;

	pMsg.npcindex = lpMsg->npcindex;

	memcpy(pMsg.account, lpMsg->account, sizeof(pMsg.account));

	pMsg.Result = 0;

	if (gQueryManager.ExecQuery("SELECT * FROM PeriodicItem WHERE Account='%s'", lpMsg->account) == 0 || gQueryManager.Fetch() == SQL_NO_DATA)
	{
		gQueryManager.Close();

		pMsg.Result = 0;
	}
	else
	{

		pMsg.Id = gQueryManager.GetAsInteger("Id");

		pMsg.Section = gQueryManager.GetAsInteger("Section");

		pMsg.ItemIndex = gQueryManager.GetAsInteger("Index");

		pMsg.Level = gQueryManager.GetAsInteger("Level");

		pMsg.Skill = gQueryManager.GetAsInteger("Skill");

		pMsg.Luck = gQueryManager.GetAsInteger("Luck");

		pMsg.Opt = gQueryManager.GetAsInteger("Opt");

		pMsg.Exc = gQueryManager.GetAsInteger("Exc");

		pMsg.Days = gQueryManager.GetAsInteger("Days");

		pMsg.IsPeriodic = gQueryManager.GetAsInteger("IsPeriodic");

		pMsg.Result = 1;

		gQueryManager.Close();
	}

	gSocketManager.DataSend(index, (BYTE*)&pMsg, sizeof(pMsg));
}

void ItemDuration::GDPeriodicItemDelRecv(SDHP_PERIODIC_ITEM_DEL_RECV * lpMsg)
{
	gQueryManager.ExecQuery("DELETE FROM PeriodicItem WHERE ItemSerial=%d", lpMsg->Serial);
	gQueryManager.Close();
}

void ItemDuration::GDPeriodicItemSaveRecv(SDHP_PERIODIC_ITEM_SAVE_RECV * lpMsg)
{
	for (int n = 0; n < lpMsg->count; n++)
	{
		SDHP_PERIODIC_ITEM_SAVE* lpInfo = (SDHP_PERIODIC_ITEM_SAVE*)(((BYTE*)lpMsg) + sizeof(SDHP_PERIODIC_ITEM_SAVE_RECV) + (sizeof(SDHP_PERIODIC_ITEM_SAVE)*n));

		if (gQueryManager.ExecQuery("SELECT ItemSerial FROM PeriodicItem WHERE ItemSerial=%d", lpInfo->serial) == 0 || gQueryManager.Fetch() == SQL_NO_DATA)
		{
			gQueryManager.Close();
			gQueryManager.ExecQuery("INSERT INTO PeriodicItem (ItemSerial,Time) VALUES (%d,%d)", lpInfo->serial, lpInfo->time);
			gQueryManager.Close();
		}
		else
		{
			gQueryManager.Close();
			gQueryManager.ExecQuery("UPDATE PeriodicItem SET Time=%d WHERE ItemSerial=%d", lpInfo->time, lpInfo->serial);
			gQueryManager.Close();
		}
	}
}
