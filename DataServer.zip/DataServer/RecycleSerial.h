#pragma once

#include <vector>
#include "CriticalSection.h"
#include "DataServerProtocol.h"

struct SDHP_RECYCLE_SERIAL_RECV
{
	PSBMSG_HEAD header; // C1:72
	DWORD serial;
};

class CRecycleSerial {
public:
	CRecycleSerial();
	~CRecycleSerial();

	void GDRecycleSerialRecv(SDHP_RECYCLE_SERIAL_RECV * lpMsg);
	bool GetSerial(DWORD* serial);

public:
	std::queue<DWORD> m_SerialRecycle;
	CCriticalSection m_critical;
};

extern CRecycleSerial gRecycleSerial;