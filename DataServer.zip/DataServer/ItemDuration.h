#pragma once

#include "DataServerProtocol.h"

struct SDHP_PERIODIC_ITEM_SEND
{
	PSWMSG_HEAD header; // C2:18:05
	WORD index;
	char account[11];
	BYTE count;
};

struct SDHP_PERIODIC_ITEM_RECV
{
	PSWMSG_HEAD header;
	WORD index;
	char account[11];
	BYTE count;
};

struct SDHP_PERIODIC_ITEM1
{
	BYTE slot;
	DWORD serial;
};

struct SDHP_PERIODIC_ITEM2
{
	BYTE slot;
	DWORD serial;
	DWORD time;
};

struct SDHP_PERIODIC_PICK_UP_RECV
{
	PSBMSG_HEAD header;
	WORD index;
	WORD npcindex;
	char account[11];
};

struct SDHP_PERIODIC_PICK_UP_SEND
{
	PSBMSG_HEAD header;
	WORD index;
	WORD npcindex;
	char account[11];
	int Id;
	int Section;
	int ItemIndex;
	int Days;
	int Level;
	int Skill;
	int Luck;
	int Opt;
	int Exc;
	int IsPeriodic;
	BYTE Result;
};

struct SDHP_PERIODIC_ITEM_DEL_RECV
{
	PSBMSG_HEAD header;
	DWORD Serial;
};

struct SDHP_PERIODIC_ITEM_SAVE_RECV
{
	PSWMSG_HEAD header; // C2:18:34
	WORD index;
	char account[11];
	BYTE count;
};

struct SDHP_PERIODIC_ITEM_SAVE
{
	DWORD serial;
	DWORD time;
};

struct ITEM_DURATION_INFO
{
	void Clear()
	{
		this->Time = 0;
		this->Serial = 0;
	};

	DWORD Time;
	DWORD Serial;
};

class ItemDuration
{
public:
	ItemDuration();
	virtual ~ItemDuration();

	void CheckDurationItens();
	void GDPeriodicItemRecv(SDHP_PERIODIC_ITEM_RECV* lpMsg, int index);
	void GDPeriodicWarehouseItemRecv(SDHP_PERIODIC_ITEM_RECV* lpMsg, int index);
	void GDPickUpItemRecv(SDHP_PERIODIC_PICK_UP_RECV* lpMsg, int index);
	void GDPeriodicItemDelRecv(SDHP_PERIODIC_ITEM_DEL_RECV* lpMsg);
	void GDPeriodicItemSaveRecv(SDHP_PERIODIC_ITEM_SAVE_RECV* lpMsg);

private:
	std::vector<ITEM_DURATION_INFO> ItemDurationList;

}; extern ItemDuration gItemDuration;