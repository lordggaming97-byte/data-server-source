#include "stdafx.h"
#include "CheckString.h"

CCheckString gCheckString;

CCheckString::CCheckString()
{

}

CCheckString::~CCheckString()
{

}

bool CCheckString::checkString(std::string szString, std::string szPattern, bool szIgnoreSpace)
{
	DWORD dwCount = 0;
	std::string szReg = "", szCharacter = "";

	if (szPattern[0] != '[' || szPattern[(szPattern.length() - 1)] != ']')
	{
		return false;
	}

	for (int i = 1; i < (int)szPattern.length(); i++)
	{
		if (szPattern[i] == ']')
		{
			if (!szReg.empty())
			{
				szCharacter += szReg;
			}

			break;
		}

		if (!szPattern.compare(i, 3, "A-Z"))
		{
			szCharacter += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			i += 2;
		}
		else if (!szPattern.compare(i, 3, "a-z"))
		{
			szCharacter += "abcdefghijklmnopqrstuvwxyz";
			i += 2;
		}
		else if (!szPattern.compare(i, 3, "0-9"))
		{
			szCharacter += "0123456789";
			i += 2;
		}
		else
		{
			szReg += szPattern[i];
		}
	}

	for (int n = 0; n < (int)szString.length(); n++)
	{
		if (szString[n] == ' ' && szIgnoreSpace)
		{
			dwCount++;
			continue;
		}

		for (int y = 0; y < (int)szCharacter.length(); y++)
		{
			if (szString[n] == szCharacter[y])
			{
				dwCount++;
				break;
			}
		}
	}

	if (dwCount == (DWORD)szString.length())
	{
		return true;
	}

	return false;
}