#include "stdafx.h"
#include "resource.h"
#include "DataServer.h"
#include "AllowableIpList.h"
#include "BadSyntax.h"
#include "GuildManager.h"
#include "MiniDump.h"
#include "QueryManager.h"
#include "ServerDisplayer.h"
#include "SocketManager.h"
#include "Util.h"
#include "Protect.h"

HINSTANCE hInst;
TCHAR szTitle[MAX_LOADSTRING];
TCHAR szWindowClass[MAX_LOADSTRING];
HWND hWnd;
char CustomerName[100];
char ResetTable[50];
int MaxCharacters;
int DisableCheckName;
int RecycleSerial;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow) // OK
{
	CMiniDump::Start();

	LoadString(hInstance,IDS_APP_TITLE,szTitle,MAX_LOADSTRING);
	LoadString(hInstance,IDC_DATASERVER,szWindowClass,MAX_LOADSTRING);

	MyRegisterClass(hInstance);

	if(InitInstance(hInstance,nCmdShow) == 0)
	{
		return 0;
	}

	GetPrivateProfileStringA(ENC("DataServerInfo"), ENC("UserEmail"), ENC("ogocx.com.br"), CustomerName, sizeof(CustomerName), ENC(".\\DataServer.ini"));

	GetPrivateProfileStringA(ENC("DataServerInfo"), ENC("ResetTable"), ENC("Resets"), ResetTable, sizeof(ResetTable), ENC(".\\DataServer.ini"));

	char buff[256];

	wsprintf(buff, ENC("[%s] DataServer (QueueSize : %d)"),DATASERVER_VERSION,0);

	SetWindowText(hWnd,buff);

	gServerDisplayer.Init(hWnd);

	WSADATA wsa;

	if(WSAStartup(MAKEWORD(2,2),&wsa) == 0)
	{
		char DataServerODBC[32] = {0};

		char DataServerUSER[32] = {0};

		char DataServerPASS[32] = {0};

		GetPrivateProfileString(ENC("DataServerInfo"), ENC("DataServerODBC"),"",DataServerODBC,sizeof(DataServerODBC), ENC(".\\DataServer.ini"));

		GetPrivateProfileString(ENC("DataServerInfo"), ENC("DataServerUSER"),"",DataServerUSER,sizeof(DataServerUSER), ENC(".\\DataServer.ini"));

		GetPrivateProfileString(ENC("DataServerInfo"), ENC("DataServerPASS"),"",DataServerPASS,sizeof(DataServerPASS), ENC(".\\DataServer.ini"));

		WORD DataServerPort = GetPrivateProfileInt(ENC("DataServerInfo"), ENC("DataServerPort"),55960, ENC(".\\DataServer.ini"));

		MaxCharacters = GetPrivateProfileInt(ENC("DataServerInfo"), ENC("MaxCharacters"), 5, ENC(".\\DataServer.ini"));

		DisableCheckName = GetPrivateProfileInt(ENC("DataServerInfo"), ENC("DisableCheckName"), 0, ENC(".\\DataServer.ini"));

		RecycleSerial = GetPrivateProfileInt(ENC("DataServerInfo"), ENC("RecycleSerial"), 0, ENC(".\\DataServer.ini"));

		if(gQueryManager.Connect(DataServerODBC,DataServerUSER,DataServerPASS) == 0)
		{
			LogAdd(LOG_RED, (char*)ENC("Could not connect to database"));
		}
		else
		{
			if(gSocketManager.Start(DataServerPort) == 0)
			{
				gQueryManager.Disconnect();
			}
			else
			{
				gAllowableIpList.Load((char*)ENC("AllowableIpList.txt"));

				gBadSyntax.Load((char*)ENC("BadSyntax.txt"));

				SetTimer(hWnd,TIMER_1000,1000,0);

				gGuildManager.Init();
			}
		}
	}
	else
	{
		LogAdd(LOG_RED, (char*)ENC("WSAStartup() failed with error: %d"),WSAGetLastError());
	}

	gServerDisplayer.PaintAllInfo();

	SetTimer(hWnd,TIMER_2000,2000,0);

	HACCEL hAccelTable = LoadAccelerators(hInstance,(LPCTSTR)IDC_DATASERVER);

	MSG msg;

	while(GetMessage(&msg,0,0,0) != 0)
	{
		if(TranslateAccelerator(msg.hwnd,hAccelTable,&msg) == 0)
		{
			TranslateMessage(&msg);
			DispatchMessageA(&msg);
		}
	}

	CMiniDump::Clean();

	return msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance) // OK
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = (WNDPROC)WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(hInstance,(LPCTSTR)IDI_DATASERVER);
	wcex.hCursor = LoadCursor(0,IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName = (LPCSTR)IDC_DATASERVER;
	wcex.lpszClassName = szWindowClass;
	wcex.hIconSm = LoadIcon(wcex.hInstance,(LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance,int nCmdShow) // OK
{
	hInst = hInstance;

	hWnd = CreateWindow(szWindowClass,szTitle,WS_OVERLAPPEDWINDOW | WS_THICKFRAME,CW_USEDEFAULT,0,600,600,0,0,hInstance,0);

	if(hWnd == 0)
	{
		return 0;
	}

	ShowWindow(hWnd,nCmdShow);
	UpdateWindow(hWnd);
	return 1;
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM lParam) // OK
{
	switch(message)
	{
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDM_ABOUT:
					DialogBox(hInst,(LPCTSTR)IDD_ABOUTBOX,hWnd,(DLGPROC)About);
					break;
				case IDM_EXIT:
					if(MessageBox(0,"Are you sure to terminate DataServer?","Ask terminate server",MB_YESNO | MB_ICONQUESTION) == IDYES)
					{
						DestroyWindow(hWnd);
					}
					break;
				default:
					return DefWindowProc(hWnd,message,wParam,lParam);
			}
			break;
		case WM_TIMER:
			switch(wParam)
			{
				case TIMER_1000:
					break;
				case TIMER_2000:
					gServerDisplayer.Run();
					break;
				default:
					break;
			}
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd,message,wParam,lParam);
	}

	return 0;
}

LRESULT CALLBACK About(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam) // OK
{
	switch(message)
	{
		case WM_INITDIALOG:
			return 1;
		case WM_COMMAND:
			if(LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg,LOWORD(wParam));
				return 1;
			}
			break;
	}

	return 0;
}
