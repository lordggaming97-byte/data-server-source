#pragma once


class CCheckString
{
public:
	CCheckString();
	virtual ~CCheckString();

	bool checkString(std::string szString, std::string szPattern, bool szIgnoreSpace);
};

extern CCheckString gCheckString;