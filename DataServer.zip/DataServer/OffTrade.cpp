#include "stdafx.h"
#include "OffTrade.h"
#include "QueryManager.h"

COffTrade gOffTrade;

COffTrade::COffTrade()
{

}

COffTrade::~COffTrade()
{

}

void COffTrade::OffTradeItemSaveRecv(PMSG_OFF_TRADE_ITEM_SAVE_RECV* lpMsg)
{
	gQueryManager.BindParameterAsBinary(1, lpMsg->item, sizeof(lpMsg->item));
	gQueryManager.ExecQuery("INSERT INTO [dbo].[OFF_TRADE_SYSTEM] ([Account],[Name],[Item],[slot],[value],[coin],[map],[x],[y]) VALUES ('%s','%s',?, %d, %d, %d, %d, %d, %d)", lpMsg->account, lpMsg->name, lpMsg->slot, lpMsg->value, lpMsg->coin, lpMsg->map, lpMsg->x, lpMsg->y);
	gQueryManager.Close();
}

void COffTrade::OffTradeItemDelete(PMSG_OFF_TRADE_DELETE_ITEM_RECV* lpMsg)
{
	if (gQueryManager.ExecQuery("SELECT * FROM OFF_TRADE_SYSTEM WHERE Account='%s' and Name='%s' and slot='%d'", lpMsg->account, lpMsg->name, lpMsg->slot) == 0 || gQueryManager.Fetch() == SQL_NO_DATA)
	{
		gQueryManager.Close();
	}
	else {
		gQueryManager.Close();

		gQueryManager.ExecQuery("DELETE FROM OFF_TRADE_SYSTEM WHERE Account='%s' and Name='%s' and slot='%d'", lpMsg->account, lpMsg->name, lpMsg->slot);
		gQueryManager.Close();
	}
}

void COffTrade::OffTradeAllItemDelete(PMSG_OFF_TRADE_DELETE_ALL_ITEM_RECV* lpMsg)
{
	if (gQueryManager.ExecQuery("SELECT * FROM OFF_TRADE_SYSTEM WHERE Account='%s' and Name='%s'", lpMsg->account, lpMsg->name) == 0 || gQueryManager.Fetch() == SQL_NO_DATA)
	{
		gQueryManager.Close();
	}
	else 
	{
		gQueryManager.Close();

		gQueryManager.ExecQuery("DELETE FROM OFF_TRADE_SYSTEM WHERE Account='%s' and Name='%s'", lpMsg->account, lpMsg->name);
		gQueryManager.Close();
	}
}
