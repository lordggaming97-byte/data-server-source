#pragma once

#include "ServerDisplayer.h"
#include "ServerManager.h"

void ErrorMessageBox(char* message,...);
void LogAdd(eLogColor color,char* text,...);
#if (DATASERVER_UPDATE>=601)
bool GetCharacterSlot(char CharacterName[10][11], char* name, BYTE* slot);
#else
bool GetCharacterSlot(char CharacterName[5][11], char* name, BYTE* slot);
#endif
bool CheckTextSyntax(char* text,int size);
int GetFreeServerIndex();
int SearchFreeServerIndex(int* index,int MinIndex,int MaxIndex,DWORD MinTime);
WORD GetServerCodeByName(char* name);
CServerManager* FindServerByCode(WORD ServerCode);

static BYTE EncDecKeyInternal1[5] = { 0x54, 0xE2, 0x32, 0xB1, 0xC8 };
static BYTE EncDecKeyInternal2[5] = { 0x88, 0xA2, 0x77, 0x15, 0xF1 };

extern int gServerCount;
