#include "stdafx.h"
#include "RecycleSerial.h"
#include "Util.h"

CRecycleSerial gRecycleSerial;

CRecycleSerial::CRecycleSerial()
{
	this->m_SerialRecycle.swap(std::queue<DWORD>());
}

CRecycleSerial::~CRecycleSerial()
{
	this->m_SerialRecycle.swap(std::queue<DWORD>());
}

void CRecycleSerial::GDRecycleSerialRecv(SDHP_RECYCLE_SERIAL_RECV* lpMsg)
{
	this->m_critical.lock();

	this->m_SerialRecycle.push(lpMsg->serial);

	this->m_critical.unlock();
}

bool CRecycleSerial::GetSerial(DWORD* serial)
{
	bool result = 0;

	this->m_critical.lock();

	if (this->m_SerialRecycle.empty() == 0) {
		(*serial) = this->m_SerialRecycle.front();

		this->m_SerialRecycle.pop();

		result = 1;
	}

	this->m_critical.unlock();

	return result;
}
