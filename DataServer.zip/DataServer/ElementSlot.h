#pragma once

#include "DataServerProtocol.h"

#define ELEMENT_SLOT_SIZE 2

struct SDHP_ELEMENT_SLOT_GET_SAVE_RECV
{
	PSBMSG_HEAD header; // C2:05:31
	WORD index;
	char account[11];
	char name[11];
};


struct SDHP_ELEMENT_SLOT_SAVE_SEND
{
	PSWMSG_HEAD header; // C2:05:32
	WORD index;
	char account[11];
	char name[11];
	BYTE ElementSlot[ELEMENT_SLOT_SIZE][MAX_ITEM_OPTION];
};

struct SDHP_ELEMENT_SLOT_SAVE_RECV
{
	PSWMSG_HEAD header; // C2:05:30
	WORD index;
	char account[11];
	char name[11];
	BYTE ElementSlot[ELEMENT_SLOT_SIZE][MAX_ITEM_OPTION];
};

class CElementSlot
{
public:
	CElementSlot();
	virtual ~CElementSlot();

	void ElementSlotGetSave(SDHP_ELEMENT_SLOT_GET_SAVE_RECV * lpMsg, int index);
	void ElementSlotSaveRecv(SDHP_ELEMENT_SLOT_SAVE_RECV * lpMsg);
};

extern CElementSlot gElementSlot;