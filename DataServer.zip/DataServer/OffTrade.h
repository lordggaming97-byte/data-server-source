#pragma once

#include "DataServerProtocol.h"

struct PMSG_OFF_TRADE_ITEM_SAVE_RECV
{
	PSBMSG_HEAD header;
	char account[11];
	char name[11];
	int value;
	int coin;
	BYTE item[16];
	BYTE slot;
	BYTE map;
	BYTE x;
	BYTE y;
};

struct PMSG_OFF_TRADE_DELETE_ITEM_RECV
{
	PSBMSG_HEAD header;
	char account[11];
	char name[11];
	BYTE slot;
};

struct PMSG_OFF_TRADE_DELETE_ALL_ITEM_RECV
{
	PSBMSG_HEAD header;
	char account[11];
	char name[11];
};

class COffTrade {
public:
	COffTrade();
	~COffTrade();

	void OffTradeItemSaveRecv(PMSG_OFF_TRADE_ITEM_SAVE_RECV * lpMsg);
	void OffTradeItemDelete(PMSG_OFF_TRADE_DELETE_ITEM_RECV* lpMsg);
	void OffTradeAllItemDelete(PMSG_OFF_TRADE_DELETE_ALL_ITEM_RECV * lpMsg);
};

extern COffTrade gOffTrade;