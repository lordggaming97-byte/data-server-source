#include "stdafx.h"

#pragma comment (lib, "libsslMT.lib")
#pragma comment (lib, "libcryptoMT.lib")
